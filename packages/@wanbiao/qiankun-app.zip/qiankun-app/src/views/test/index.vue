<template>
  <div class="test">测试</div>
</template>

<script lang="ts">
  import { defineComponent, onMounted, ref } from 'vue';
  export default defineComponent({
    setup(props, ctx) {
      onMounted(() => {});
      return {};
    }
  });
</script>

<style lang="scss" scoped></style>
