export type LoginParams = {
  username?: string;
  password?: string;
};
